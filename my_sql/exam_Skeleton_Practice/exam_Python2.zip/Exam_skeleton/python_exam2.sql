SELECT * FROM band_db.bands;

INSERT INTO bands(band_name, founding_member, genre, home_city, user_id)
VALUES('Dru Bills', 'Andrew Bishop', 'Country Hip-Hop', 'Albany', 1);

