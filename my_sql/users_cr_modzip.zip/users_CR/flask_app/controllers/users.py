from flask import render_template, request, redirect, session

from flask_app import app
# import the class from friend.py
from flask_app.models.user import User

@app.route('/')
def index():
    users = User
    print(users)
    return render_template("users.html", users=User.get_all())

@app.route('/user/create',methods=['POST'])
def create_user():
    data={
        "first_name": request.form["first_name"],
        "last_name": request.form["last_name"],
        "email": request.form["email"],
        # "created_at": request.form["created_at"],
        # "actions": request.form["actions"]
    }
    print(request.form)
    User.save(data)
    return redirect('/')

@app.route('/users')
def users():
    return render_template("users.html", users=User.get_all())

@app.route('/form')
def form():
    return render_template('new_user.html')

@app.route('/user/edit/<int:id>')
def edit(id):
        data ={
            "id":id
        }
        return render_template("edit_user.html", user=User.get_one(data))

@app.route('/users/update/<int:id>',methods=['POST'])
def update(id):
    data ={"id":id,
    "first_name":request.form["first_name"],
    "last_name": request.form["last_name"],
    "email": request.form["email"]}
    User.update(data)
    return redirect('/')

@app.route('/user/show/<int:id>')
def show(id):
    data ={
        "id":id
    }
    return render_template("users_show.html", user=User.get_one(data))           


@app.route('/user/destroy/<int:id>')
def destroy(id):
    data ={
        "id":id
    }
    User.destroy(data)
    return redirect('/users') 
